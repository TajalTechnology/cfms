package com.ibasl.cfms.controller;

import java.io.PrintWriter;
import java.security.Principal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.ibasl.cfms.model.CFJobs;
import com.ibasl.cfms.model.CFStatus;
import com.ibasl.cfms.model.Country;
import com.ibasl.cfms.model.Customer;
import com.ibasl.cfms.model.Supplier;
import com.ibasl.cfms.model.User;
import com.ibasl.cfms.service.CommonService;
import com.ibasl.cfms.util.CFMSEntitys;
import com.ibasl.cfms.util.Constants;

@Controller
@PropertySource("classpath:common.properties")
public class CFJobsController implements Constants, CFMSEntitys {
	@Autowired
	private CommonService commonService;

	@SuppressWarnings("unused")
	@Autowired
	private JavaMailSender mailSender;

	@Value("${cc.email.addresss}")
	String ccEmailAddresss;

	@Value("${common.email.address}")
	String commonEmailAddress;
	
	@RequestMapping(value = "/newCFJobsForm", method = RequestMethod.GET)
	public ModelAndView addCFJobs(@ModelAttribute("command") CFJobs cfJobs, BindingResult result, ModelMap model, Principal principal) {
		
		if (principal == null) {
			return new ModelAndView("redirect:/login");
		}
		
		List<CFStatus> cfStatusList = commonService.getObjectListByAnyColumn(CF_STATUS, "status", ACTIVE)
				.stream().map(e -> (CFStatus) e).collect(Collectors.toList());
		
		List<Country> countryList = commonService.getObjectListByAnyColumn(COUNTRY, "status", ACTIVE)
				.stream().map(e -> (Country) e).collect(Collectors.toList());
		
		List<Supplier> supplierList = commonService.getObjectListByAnyColumn(SUPPLIER, "status", ACTIVE)
				.stream().map(e -> (Supplier) e).collect(Collectors.toList());
		
		List<Customer> customerList = commonService.getObjectListByAnyColumn(CUSTOMER, "status", ACTIVE)
				.stream().map(e -> (Customer) e).collect(Collectors.toList());
		
		model.put("cfStatusList", cfStatusList);
		model.put("countryList", countryList);
		model.put("supplierList", supplierList);
		model.put("customerList", customerList);
		
		model.put("edit", false);
		return new ModelAndView("addCFJobs", model);
	}
	
	@RequestMapping(value = "/saveCFJobs", method = RequestMethod.POST)
	@ResponseBody
	public ModelAndView saveCFJobs(@ModelAttribute("command") CFJobs cfJobs, HttpSession session, HttpServletRequest request,
			RedirectAttributes redirectAttributes, Principal principal) {
		
		if (principal == null) {
			return new ModelAndView("redirect:/login");
		}
		
		User loginUser =  (User) session.getAttribute("loginEmployee");
		
		CFStatus cfStatus = null;
		Supplier supplier = null;
		Customer customer = null;
		Country country = null;
		
		if(cfJobs.getCfStatusId() != null) {
			cfStatus = (CFStatus) commonService.getAnObjectByAnyUniqueColumn(CF_STATUS, "id", cfJobs.getCfStatusId().toString());
		}
		
		if(cfJobs.getSupplierId() != null) {
			supplier = (Supplier) commonService.getAnObjectByAnyUniqueColumn(SUPPLIER, "id", cfJobs.getSupplierId().toString());
		}
		
		if(cfJobs.getCustomerId() != null) {
			customer = (Customer) commonService.getAnObjectByAnyUniqueColumn(CUSTOMER, "id", cfJobs.getCustomerId().toString());
		}
		
		if(cfJobs.getCountryOfOriginId() != null) {
			country = (Country) commonService.getAnObjectByAnyUniqueColumn(COUNTRY, "id", cfJobs.getCountryOfOriginId().toString());
		}
				
		if(cfJobs.getId() != null) {		
			CFJobs cfJobsById = (CFJobs)commonService.getAnObjectByAnyUniqueColumn(CF_JOBS, "id", cfJobs.getId().toString());
			CFJobs vgJobsByJobsNo= (CFJobs)commonService.getAnObjectByAnyUniqueColumn(CF_JOBS, "jobNo", cfJobs.getJobNo());
			if(cfJobsById.getId().toString().equals(vgJobsByJobsNo.getId().toString())) {
				
				cfJobsById.setCfStatus(cfStatus);
				cfJobsById.setSupplier(supplier);
				cfJobsById.setCustomer(customer);
				cfJobsById.setCountryOfOrigin(country);
				
				cfJobsById.setModifiedBy(loginUser);
				cfJobsById.setModifiedDate(new Date());
				
				commonService.saveOrUpdateModelObjectToDB(cfJobsById);
				redirectAttributes.addFlashAttribute("success", "Successfully Saved.");
				return new ModelAndView("redirect:/cfJobsList");
			} else {
				redirectAttributes.addFlashAttribute("success", "Operation failed. Please Try again.");
				return new ModelAndView("redirect:/cfJobsList");
			}
			
			
		} else {
			CFJobs cfJobsByJobsNo= (CFJobs)commonService.getAnObjectByAnyUniqueColumn(CF_JOBS, "jobNo", cfJobs.getJobNo());
			if(cfJobsByJobsNo == null) {
				
				cfJobs.setCfStatus(cfStatus);
				cfJobs.setSupplier(supplier);
				cfJobs.setCustomer(customer);
				cfJobs.setCountryOfOrigin(country);
				
				cfJobs.setCreatedBy(loginUser);
				cfJobs.setCreatedDate(new Date());
				commonService.saveOrUpdateModelObjectToDB(cfJobs);
				
				redirectAttributes.addFlashAttribute("success", "Successfully Saved.");
				return new ModelAndView("redirect:/cfJobsList");
			} else {
				redirectAttributes.addFlashAttribute("success", "This type of entry already exists. Please try again.");
				return new ModelAndView("redirect:/cfJobsList");
			}
			
		}
		
	}
	
	// method to CFJobs delete
	@RequestMapping(value = "/deleteCFJobs/{id}", method = RequestMethod.GET)
	public ModelAndView deleteCFJobs(@PathVariable("id") String id, RedirectAttributes redirectAttributes,
			Principal principal, HttpSession session) {
		if (principal == null) {
			return new ModelAndView("redirect:/login");
		}
		
		User loginUser =  (User) session.getAttribute("loginEmployee");
		
		CFJobs cfJobsById = (CFJobs)commonService.getAnObjectByAnyUniqueColumn(CF_JOBS, "id", id);
		cfJobsById.setModifiedBy(loginUser);
		cfJobsById.setModifiedDate(new Date());
		cfJobsById.setStatus(Integer.parseInt(INACTIVE));
		commonService.saveOrUpdateModelObjectToDB(cfJobsById);
		
		redirectAttributes.addFlashAttribute("success", "Operation Successfull.");
		return new ModelAndView("redirect:/CFJobsList");
	}
	
	// method to CFJobs show
	@RequestMapping(value = "/showCFJobs/{id}", method = RequestMethod.GET)
	public ModelAndView showCFJobs(@PathVariable("id") String id, ModelMap model, RedirectAttributes redirectAttributes,
			Principal principal) {
		if (principal == null) {
			return new ModelAndView("redirect:/login");
		}
		
		model.put("cfJobs", (CFJobs) commonService.getAnObjectByAnyUniqueColumn(CF_JOBS, "id", id));
		return new ModelAndView("showCFJobs", model);
	}

	@RequestMapping(value = "/editCFJobs/{id}", method = RequestMethod.GET)
	public ModelAndView editCFJobs(@ModelAttribute("command") CFJobs cfJobs, BindingResult result,
			@PathVariable("id") String id, ModelMap model, Principal principal) {
		
		if (principal == null) {
			return new ModelAndView("redirect:/login");
		}
		
		List<CFStatus> cfStatusList = commonService.getObjectListByAnyColumn(CF_STATUS, "status", ACTIVE)
				.stream().map(e -> (CFStatus) e).collect(Collectors.toList());
		
		List<Country> countryList = commonService.getObjectListByAnyColumn(COUNTRY, "status", ACTIVE)
				.stream().map(e -> (Country) e).collect(Collectors.toList());
		
		List<Supplier> supplierList = commonService.getObjectListByAnyColumn(SUPPLIER, "status", ACTIVE)
				.stream().map(e -> (Supplier) e).collect(Collectors.toList());
		
		List<Customer> customerList = commonService.getObjectListByAnyColumn(CUSTOMER, "status", ACTIVE)
				.stream().map(e -> (Customer) e).collect(Collectors.toList());
		
		model.put("cfStatusList", cfStatusList);
		model.put("countryList", countryList);
		model.put("supplierList", supplierList);
		model.put("customerList", customerList);
		
		model.put("cfJobs", (CFJobs) commonService.getAnObjectByAnyUniqueColumn(CF_JOBS, "id", id));
		model.put("edit", true);
		return new ModelAndView("editCFJobs", model);

	}

	@SuppressWarnings("unused")
	@RequestMapping(value = "/checkUniqueCFJobs", method = RequestMethod.POST)
	private @ResponseBody void checkUniqueCFJobs(HttpServletRequest request, Principal principal,
			HttpServletResponse response) throws JsonGenerationException, JsonMappingException, Exception {
		
		String jobNo = request.getParameter("jobNo").toString();
		String id = request.getParameter("id");
		
		String toJson = "";
		PrintWriter out = response.getWriter();
		Gson gson = new Gson();
		JsonObject myObj = new JsonObject();
		ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
		CFJobs cfJobs = (CFJobs) commonService.getAnObjectByAnyUniqueColumn(CF_JOBS, "jobNo", jobNo);
		
		CFJobs cfJobsById = null;
		
		if(id != null && id.length() > 0) {
			cfJobsById = (CFJobs) commonService.getAnObjectByAnyUniqueColumn(CF_JOBS, "id", id);
		}
		
		if(cfJobs != null && cfJobsById != null) {
			if(cfJobs.getId().toString().equals(cfJobsById.getId().toString())) {
				cfJobs = null;
			}
		}
		JsonElement cfJobsObject = gson.toJsonTree(cfJobs);
		myObj.add("cfJobsInfo", cfJobsObject);
		out.println(myObj.toString());

		out.close();

	}

	@RequestMapping(value = "/cfJobsList", method = RequestMethod.GET)
	public ModelAndView cfJobsList(ModelMap model, Principal principal) {
		if (principal == null) {
			return new ModelAndView("redirect:/login");
		}
		List<CFJobs> cfJobsList = commonService.getObjectListByAnyColumn(CF_JOBS, "status", ACTIVE)
				.stream().map(e -> (CFJobs) e).collect(Collectors.toList());
		model.put("cfJobsList", cfJobsList);
		return new ModelAndView("cfJobsList", model);
	}
	
	@RequestMapping(value="/customerJobList/{id}", method = RequestMethod.GET)
	public ModelAndView customerJobList(@PathVariable("id") String id, Principal principal) {
		if(principal == null) {
			return new ModelAndView("redirect:/logout");
		}
		
		Customer customer = (Customer) commonService.getAnObjectByAnyUniqueColumn(CUSTOMER, "id", id);
		
		List<CFJobs> cfJobsList = commonService.getObjectListByTwoColumn(CF_JOBS, "status", ACTIVE, "customer.id", customer.getId().toString())
				.stream().map(e -> (CFJobs) e).collect(Collectors.toList());
		
 		Map<String,Object> model = new HashMap<String, Object>();
 		model.put("customer", customer);
 		model.put("cfJobsList", cfJobsList);
 		return new ModelAndView("customerJobList", model);
	}
}
