package com.ibasl.cfms.controller;

import java.io.PrintWriter;
import java.security.Principal;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.ibasl.cfms.service.CommonService;
import com.ibasl.cfms.util.CFMSEntitys;
import com.ibasl.cfms.util.Constants;
import com.ibasl.cfms.model.CFStatus;
import com.ibasl.cfms.model.User;

@Controller
@PropertySource("classpath:common.properties")
public class CFStatusController implements Constants, CFMSEntitys {
	
	@Autowired
	private CommonService commonService;

	@SuppressWarnings("unused")
	@Autowired
	private JavaMailSender mailSender;

	@Value("${cc.email.addresss}")
	String ccEmailAddresss;

	@Value("${common.email.address}")
	String commonEmailAddress;
	
	@RequestMapping(value = "/newCFStatusForm", method = RequestMethod.GET)
	public ModelAndView addCFStatus(@ModelAttribute("command") CFStatus cfStatus, BindingResult result, ModelMap model, Principal principal) {
		
		if (principal == null) {
			return new ModelAndView("redirect:/login");
		}
		
		model.put("edit", false);
		return new ModelAndView("addCFStatus", model);
	}
	
	@RequestMapping(value = "/saveCFStatus", method = RequestMethod.POST)
	@ResponseBody
	public ModelAndView saveCFStatus(@ModelAttribute("command") CFStatus cfStatus, HttpSession session, HttpServletRequest request,
			RedirectAttributes redirectAttributes, Principal principal) {
		
		if (principal == null) {
			return new ModelAndView("redirect:/login");
		}
		
		User loginUser =  (User) session.getAttribute("loginEmployee");
				
		if(cfStatus.getId() != null) {		
			CFStatus cfStatusById = (CFStatus)commonService.getAnObjectByAnyUniqueColumn(CF_STATUS, "id", cfStatus.getId().toString());
			CFStatus cfStatusByState = (CFStatus)commonService.getAnObjectByAnyUniqueColumn(CF_STATUS, "state", cfStatus.getState().toString());
			if(cfStatusById.getId().toString().equals(cfStatusByState.getId().toString())) {
				cfStatusById.setRemarks(cfStatus.getRemarks());
				cfStatusById.setStatus(cfStatus.getStatus());
				cfStatusById.setModifiedBy(loginUser);
				cfStatusById.setModifiedDate(new Date());
				
				commonService.saveOrUpdateModelObjectToDB(cfStatusById);
				redirectAttributes.addFlashAttribute("success", "Successfully Saved.");
				return new ModelAndView("redirect:/cfStatusList");
			} else {
				redirectAttributes.addFlashAttribute("success", "Operation failed. Please Try again.");
				return new ModelAndView("redirect:/cfStatusList");
			}
			
			
		} else {
			CFStatus cfStatusByState = (CFStatus)commonService.getAnObjectByAnyUniqueColumn(CF_STATUS, "state", cfStatus.getState().toString());
			if(cfStatusByState == null) {
				cfStatus.setCreatedBy(loginUser);
				cfStatus.setCreatedDate(new Date());
				commonService.saveOrUpdateModelObjectToDB(cfStatus);
				redirectAttributes.addFlashAttribute("success", "Successfully Saved.");
				return new ModelAndView("redirect:/cfStatusList");
			} else {
				redirectAttributes.addFlashAttribute("success", "This type of entry already exists. Please try again.");
				return new ModelAndView("redirect:/cfStatusList");
			}
			
		}
		
	}
	
	// method to vehicle delete
	@RequestMapping(value = "/deleteCFStatus/{id}", method = RequestMethod.GET)
	public ModelAndView deleteCFStatus(@PathVariable("id") String id, RedirectAttributes redirectAttributes,
			Principal principal, HttpSession session) {
		if (principal == null) {
			return new ModelAndView("redirect:/login");
		}
		
		User loginUser =  (User) session.getAttribute("loginEmployee");
		
		CFStatus cfStatusById = (CFStatus)commonService.getAnObjectByAnyUniqueColumn(CF_STATUS, "id", id);
		cfStatusById.setModifiedBy(loginUser);
		cfStatusById.setModifiedDate(new Date());
		cfStatusById.setStatus(Integer.parseInt(INACTIVE));
		commonService.saveOrUpdateModelObjectToDB(cfStatusById);
		redirectAttributes.addFlashAttribute("success", "Operation Successfull.");
		return new ModelAndView("redirect:/CFStatusList");
	}
	
	// method to vehicle show
	@RequestMapping(value = "/showCFStatus/{id}", method = RequestMethod.GET)
	public ModelAndView showCFStatus(@PathVariable("id") String id, ModelMap model, RedirectAttributes redirectAttributes,
			Principal principal) {
		if (principal == null) {
			return new ModelAndView("redirect:/login");
		}
		model.put("cfStatus", (CFStatus) commonService.getAnObjectByAnyUniqueColumn(CF_STATUS, "id", id));
		
		return new ModelAndView("showCFStatus", model);
	}

	@RequestMapping(value = "/editCFStatus/{id}", method = RequestMethod.GET)
	public ModelAndView editCFStatus(@ModelAttribute("command") CFStatus CFStatus, BindingResult result,
			@PathVariable("id") String id, ModelMap model, Principal principal) {
		if (principal == null) {
			return new ModelAndView("redirect:/login");
		}
		
		model.put("cfStatus", (CFStatus) commonService.getAnObjectByAnyUniqueColumn(CF_STATUS, "id", id));
		model.put("edit", true);
		return new ModelAndView("editCFStatus", model);

	}

	@SuppressWarnings("unused")
	@RequestMapping(value = "/checkUniqueCFStatus", method = RequestMethod.POST)
	private @ResponseBody void checkUniqueCFStatus(HttpServletRequest request, Principal principal,
			HttpServletResponse response) throws JsonGenerationException, JsonMappingException, Exception {
		
		String state = request.getParameter("state").toString();
		String id = request.getParameter("id");
		
		String toJson = "";
		PrintWriter out = response.getWriter();
		Gson gson = new Gson();
		JsonObject myObj = new JsonObject();
		ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
		CFStatus cfStatus = (CFStatus) commonService.getAnObjectByAnyUniqueColumn(CF_STATUS, "state", state);
		
		CFStatus cfStatusById = null;
		
		if(id != null && id.length() > 0) {
			cfStatusById = (CFStatus) commonService.getAnObjectByAnyUniqueColumn(CF_STATUS, "id", id);
		}
		
		if(cfStatus != null && cfStatusById != null) {
			if(cfStatus.getId().toString().equals(cfStatusById.getId().toString())) {
				cfStatus = null;
			}
		}
		JsonElement cfStatusObject = gson.toJsonTree(cfStatus);
		myObj.add("cfStatusInfo", cfStatusObject);
		out.println(myObj.toString());

		out.close();

	}

	@RequestMapping(value = "/cfStatusList", method = RequestMethod.GET)
	public ModelAndView CFStatusList(ModelMap model, Principal principal) {
		if (principal == null) {
			return new ModelAndView("redirect:/login");
		}
		List<CFStatus> cfStatusList = commonService.getAllObjectList(CF_STATUS)
				.stream().map(e -> (CFStatus) e).collect(Collectors.toList());
		model.put("cfStatusList", cfStatusList);
		return new ModelAndView("cfStatusList", model);
	}
}
