package com.ibasl.cfms.controller;

import java.io.PrintWriter;
import java.security.Principal;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import javax.mail.MessagingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.ibasl.cfms.model.CFJobs;
import com.ibasl.cfms.model.Customer;
import com.ibasl.cfms.model.User;
import com.ibasl.cfms.model.UserRole;
import com.ibasl.cfms.service.CommonService;
import com.ibasl.cfms.util.CFMSEntitys;
import com.ibasl.cfms.util.Constants;
import com.ibasl.cfms.util.SendEmail;

@Controller
@PropertySource("classpath:common.properties")
public class CustomerController implements Constants, CFMSEntitys {
	@Autowired
	private CommonService commonService;

	@SuppressWarnings("unused")
	@Autowired
	private JavaMailSender mailSender;

	@Value("${cc.email.addresss}")
	String ccEmailAddresss;

	@Value("${common.email.address}")
	String commonEmailAddress;
	
	@RequestMapping(value = "/newCustomerForm", method = RequestMethod.GET)
	public ModelAndView addCustomer(@ModelAttribute("command") Customer customer, BindingResult result, ModelMap model, Principal principal) {
		
		if (principal == null) {
			return new ModelAndView("redirect:/login");
		}
		
		model.put("edit", false);
		return new ModelAndView("addCustomer", model);
	}
	
	@RequestMapping(value = "/saveCustomer", method = RequestMethod.POST)
	@ResponseBody
	public ModelAndView saveCustomer(@ModelAttribute("command") Customer customer, HttpSession session, HttpServletRequest request,
			RedirectAttributes redirectAttributes, Principal principal) {
		
		if (principal == null) {
			return new ModelAndView("redirect:/login");
		}
		
		String loginUrl = "http://" + request.getServerName() + ":" + request.getServerPort() + request.getContextPath()+"/login";
		User loginUser =  (User) session.getAttribute("loginEmployee");
		
		if(customer.getId() != null) {		
			Customer customerById = (Customer)commonService.getAnObjectByAnyUniqueColumn(CUSTOMER, "id", customer.getId().toString());
			Customer customerByCustomerId = (Customer)commonService.getAnObjectByAnyUniqueColumn(CUSTOMER, "customerId", customer.getCustomerId().toString());
			if(customerById.getId().toString().equals(customerByCustomerId.getId().toString())) {
				
				customerById.setCityInsider(customer.getCityInsider());
				customerById.setContactNo(customer.getContactNo());
				customerById.setContactPerson(customer.getContactPerson());
				customerById.setCustomerAddress(customer.getCustomerAddress());
				customerById.setName(customer.getName());
				customerById.setWebsite(customer.getWebsite());
				
				customerById.setRemarks(customer.getRemarks());
				customerById.setStatus(customer.getStatus());
				customerById.setModifiedBy(loginUser);
				customerById.setModifiedDate(new Date());
				
				commonService.saveOrUpdateModelObjectToDB(customerById);
				redirectAttributes.addFlashAttribute("success", "Successfully Saved.");
				return new ModelAndView("redirect:/customerList");
			} else {
				redirectAttributes.addFlashAttribute("success", "Operation failed. Please Try again.");
				return new ModelAndView("redirect:/customerList");
			}
			
			
		} else {
			Customer customerByCustomerId = (Customer)commonService.getAnObjectByAnyUniqueColumn(CUSTOMER, "customerId", customer.getCustomerId().toString());
			if(customerByCustomerId == null) {
				customer.setCreatedBy(loginUser);
				customer.setCreatedDate(new Date());
				commonService.saveOrUpdateModelObjectToDB(customer);
				
				//add as user start
				Customer customerDB = (Customer)commonService.getAnObjectByAnyUniqueColumn(CUSTOMER, "customerId", customer.getCustomerId().toString());
				User newUser = new User();
				newUser.setUserName(customer.getCustomerId());
				newUser.setPassword(DEFAULT_PASSWORD);
				
				newUser.setInsertDate(new Date());
				newUser.setInsertedBy(loginUser.getFullName());
				newUser.setFullName(customerDB.getName());
				newUser.setCustomer(customerDB);
				newUser.setContactNo(customerDB.getContactNo());
				newUser.setEmail(customerDB.getEmailAddress());
				newUser.setStatus(ACTIVE);
				commonService.saveOrUpdateModelObjectToDB(newUser);
				
				//set role to user
				User newUserdb = (User)commonService.getAnObjectByAnyUniqueColumn(USER, "userName", newUser.getUserName());
				UserRole userRole = new UserRole();
				userRole.setAuthority(AUTH_USER);
				userRole.setUserId(newUserdb.getId());
				commonService.saveOrUpdateModelObjectToDB(userRole);
				//send mail to user
				SendEmail se = new SendEmail();
				try {
					se.newCustomerRegistrationMail(mailSender, customer, newUser.getUserName(), DEFAULT_PASSWORD, loginUrl, ccEmailAddresss);
				} catch (MessagingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				//add as user end
				
				redirectAttributes.addFlashAttribute("success", "Successfully Saved.");
				return new ModelAndView("redirect:/customerList");
			} else {
				redirectAttributes.addFlashAttribute("success", "This type of entry already exists. Please try again.");
				return new ModelAndView("redirect:/customerList");
			}
			
		}
		
	}
	
	// method to customer delete
	@RequestMapping(value = "/deleteCustomer/{id}", method = RequestMethod.GET)
	public ModelAndView deleteCustomer(@PathVariable("id") String id, RedirectAttributes redirectAttributes,
			Principal principal, HttpSession session) {
		if (principal == null) {
			return new ModelAndView("redirect:/login");
		}
		
		User loginUser =  (User) session.getAttribute("loginEmployee");
		
		Customer customerById = (Customer)commonService.getAnObjectByAnyUniqueColumn(CUSTOMER, "id", id);
		customerById.setModifiedBy(loginUser);
		customerById.setModifiedDate(new Date());
		customerById.setStatus(Integer.parseInt(INACTIVE));
		commonService.saveOrUpdateModelObjectToDB(customerById);
		
		redirectAttributes.addFlashAttribute("success", "Operation Successfull.");
		return new ModelAndView("redirect:/CustomerList");
	}
	
	// method to customer show
	@RequestMapping(value = "/showCustomer/{id}", method = RequestMethod.GET)
	public ModelAndView showCustomer(@PathVariable("id") String id, ModelMap model, RedirectAttributes redirectAttributes,
			Principal principal) {
		if (principal == null) {
			return new ModelAndView("redirect:/login");
		}
		
		List<CFJobs> cfJobsList = commonService.getObjectListByAnyColumn(CF_JOBS, "customer.id", id)
				.stream().map(e -> (CFJobs) e).collect(Collectors.toList());
		
		model.put("cfJobsList", cfJobsList);		
		model.put("customer", (Customer) commonService.getAnObjectByAnyUniqueColumn(CUSTOMER, "id", id));
		return new ModelAndView("showCustomer", model);
	}

	@RequestMapping(value = "/editCustomer/{id}", method = RequestMethod.GET)
	public ModelAndView editCustomer(@ModelAttribute("command") Customer customer, BindingResult result,
			@PathVariable("id") String id, ModelMap model, Principal principal) {
		if (principal == null) {
			return new ModelAndView("redirect:/login");
		}
		
		model.put("customer", (Customer) commonService.getAnObjectByAnyUniqueColumn(CUSTOMER, "id", id));
		model.put("edit", true);
		return new ModelAndView("editCustomer", model);

	}

	@SuppressWarnings("unused")
	@RequestMapping(value = "/checkUniqueCustomer", method = RequestMethod.POST)
	private @ResponseBody void checkUniqueCustomer(HttpServletRequest request, Principal principal,
			HttpServletResponse response) throws JsonGenerationException, JsonMappingException, Exception {
		
		String customerId = request.getParameter("customerId").toString();
		String id = request.getParameter("id");
		
		String toJson = "";
		PrintWriter out = response.getWriter();
		Gson gson = new Gson();
		JsonObject myObj = new JsonObject();
		ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
		Customer customer = (Customer) commonService.getAnObjectByAnyUniqueColumn(CUSTOMER, "customerId", customerId);
		
		Customer customerById = null;
		
		if(id != null && id.length() > 0) {
			customerById = (Customer) commonService.getAnObjectByAnyUniqueColumn(CUSTOMER, "id", id);
		}
		
		if(customer != null && customerById != null) {
			if(customer.getId().toString().equals(customerById.getId().toString())) {
				customer = null;
			}
		}
		JsonElement customerObject = gson.toJsonTree(customer);
		myObj.add("customerInfo", customerObject);
		out.println(myObj.toString());

		out.close();

	}

	@RequestMapping(value = "/customerList", method = RequestMethod.GET)
	public ModelAndView CustomerList(ModelMap model, Principal principal) {
		if (principal == null) {
			return new ModelAndView("redirect:/login");
		}
		List<Customer> customerList = commonService.getAllObjectList(CUSTOMER)
				.stream().map(e -> (Customer) e).collect(Collectors.toList());
		model.put("customerList", customerList);
		return new ModelAndView("customerList", model);
	}
}
