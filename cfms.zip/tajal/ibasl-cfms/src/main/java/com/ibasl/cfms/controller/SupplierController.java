package com.ibasl.cfms.controller;

import java.io.PrintWriter;
import java.security.Principal;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.ibasl.cfms.model.Country;
import com.ibasl.cfms.model.Supplier;
import com.ibasl.cfms.model.User;
import com.ibasl.cfms.service.CommonService;
import com.ibasl.cfms.util.CFMSEntitys;
import com.ibasl.cfms.util.Constants;

@Controller
@PropertySource("classpath:common.properties")
public class SupplierController implements Constants, CFMSEntitys {
	@Autowired
	private CommonService commonService;

	@SuppressWarnings("unused")
	@Autowired
	private JavaMailSender mailSender;

	@Value("${cc.email.addresss}")
	String ccEmailAddresss;

	@Value("${common.email.address}")
	String commonEmailAddress;
	
	@RequestMapping(value = "/newSupplierForm", method = RequestMethod.GET)
	public ModelAndView addSupplier(@ModelAttribute("command") Supplier supplier, BindingResult result, ModelMap model, Principal principal) {
		
		if (principal == null) {
			return new ModelAndView("redirect:/login");
		}
		
		List<Country> countryList = commonService.getObjectListByAnyColumn(COUNTRY, "status", ACTIVE)
				.stream().map(e -> (Country) e).collect(Collectors.toList());
		model.put("countryList", countryList);
		model.put("edit", false);
		return new ModelAndView("addSupplier", model);
	}
	
	@RequestMapping(value = "/saveSupplier", method = RequestMethod.POST)
	@ResponseBody
	public ModelAndView saveSupplier(@ModelAttribute("command") Supplier supplier, HttpSession session, HttpServletRequest request,
			RedirectAttributes redirectAttributes, Principal principal) {
		
		if (principal == null) {
			return new ModelAndView("redirect:/login");
		}
		
		User loginUser =  (User) session.getAttribute("loginEmployee");
		
		Country country = null;
		if(supplier.getCountryId() != null) {
			country = (Country)commonService.getAnObjectByAnyUniqueColumn(COUNTRY, "id", supplier.getCountryId());
		}
				
		if(supplier.getId() != null) {		
			Supplier supplierById = (Supplier)commonService.getAnObjectByAnyUniqueColumn(SUPPLIER, "id", supplier.getId().toString());
			Supplier supplierBySupplierId = (Supplier)commonService.getAnObjectByAnyUniqueColumn(SUPPLIER, "supplierId", supplier.getSupplierId().toString());
			if(supplierById.getId().toString().equals(supplierBySupplierId.getId().toString())) {
				
				
				supplierById.setContactNo(supplier.getContactNo());
				supplierById.setContactPerson(supplier.getContactPerson());
				supplierById.setSupplierAddress(supplier.getSupplierAddress());
				supplierById.setName(supplier.getName());
				
				supplierById.setCountry(country);
				
				supplierById.setRemarks(supplier.getRemarks());
				supplierById.setStatus(supplier.getStatus());
				supplierById.setModifiedBy(loginUser);
				supplierById.setModifiedDate(new Date());
				
				commonService.saveOrUpdateModelObjectToDB(supplierById);
				redirectAttributes.addFlashAttribute("success", "Successfully Saved.");
				return new ModelAndView("redirect:/supplierList");
			} else {
				redirectAttributes.addFlashAttribute("success", "Operation failed. Please Try again.");
				return new ModelAndView("redirect:/supplierList");
			}
			
			
		} else {
			Supplier SupplierBySupplierId = (Supplier)commonService.getAnObjectByAnyUniqueColumn(SUPPLIER, "supplierId", supplier.getSupplierId());
			if(SupplierBySupplierId == null) {
				supplier.setCreatedBy(loginUser);
				supplier.setCreatedDate(new Date());
				commonService.saveOrUpdateModelObjectToDB(supplier);
				
				redirectAttributes.addFlashAttribute("success", "Successfully Saved.");
				return new ModelAndView("redirect:/supplierList");
			} else {
				redirectAttributes.addFlashAttribute("success", "This type of entry already exists. Please try again.");
				return new ModelAndView("redirect:/supplierList");
			}
			
		}
		
	}
	
	// method to Supplier delete
	@RequestMapping(value = "/deleteSupplier/{id}", method = RequestMethod.GET)
	public ModelAndView deleteSupplier(@PathVariable("id") String id, RedirectAttributes redirectAttributes,
			Principal principal, HttpSession session) {
		if (principal == null) {
			return new ModelAndView("redirect:/login");
		}
		
		User loginUser =  (User) session.getAttribute("loginEmployee");
		
		Supplier supplierById = (Supplier)commonService.getAnObjectByAnyUniqueColumn(SUPPLIER, "id", id);
		supplierById.setModifiedBy(loginUser);
		supplierById.setModifiedDate(new Date());
		supplierById.setStatus(Integer.parseInt(INACTIVE));
		commonService.saveOrUpdateModelObjectToDB(supplierById);
		
		redirectAttributes.addFlashAttribute("success", "Operation Successfull.");
		return new ModelAndView("redirect:/supplierList");
	}
	
	// method to Supplier show
	@RequestMapping(value = "/showSupplier/{id}", method = RequestMethod.GET)
	public ModelAndView showSupplier(@PathVariable("id") String id, ModelMap model, RedirectAttributes redirectAttributes,
			Principal principal) {
		
		if (principal == null) {
			return new ModelAndView("redirect:/login");
		}
			
		model.put("supplier", (Supplier) commonService.getAnObjectByAnyUniqueColumn(SUPPLIER, "id", id));
		return new ModelAndView("showSupplier", model);
	}

	@RequestMapping(value = "/editSupplier/{id}", method = RequestMethod.GET)
	public ModelAndView editSupplier(@ModelAttribute("command") Supplier Supplier, BindingResult result,
			@PathVariable("id") String id, ModelMap model, Principal principal) {
		if (principal == null) {
			return new ModelAndView("redirect:/login");
		}
		
		List<Country> countryList = commonService.getObjectListByAnyColumn(COUNTRY, "status", ACTIVE)
				.stream().map(e -> (Country) e).collect(Collectors.toList());
		
		model.put("countryList", countryList);
		
		model.put("supplier", (Supplier) commonService.getAnObjectByAnyUniqueColumn(SUPPLIER, "id", id));
		model.put("edit", true);
		return new ModelAndView("editSupplier", model);

	}

	@SuppressWarnings("unused")
	@RequestMapping(value = "/checkUniqueSupplier", method = RequestMethod.POST)
	private @ResponseBody void checkUniqueSupplier(HttpServletRequest request, Principal principal,
			HttpServletResponse response) throws JsonGenerationException, JsonMappingException, Exception {
		
		String supplierId = request.getParameter("supplierId").toString();
		String id = request.getParameter("id");
		
		String toJson = "";
		PrintWriter out = response.getWriter();
		Gson gson = new Gson();
		JsonObject myObj = new JsonObject();
		ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
		Supplier supplier = (Supplier) commonService.getAnObjectByAnyUniqueColumn(SUPPLIER, "supplierId", supplierId);
		
		Supplier supplierById = null;
		
		if(id != null && id.length() > 0) {
			supplierById = (Supplier) commonService.getAnObjectByAnyUniqueColumn(SUPPLIER, "id", id);
		}
		
		if(supplier != null && supplierById != null) {
			if(supplier.getId().toString().equals(supplierById.getId().toString())) {
				supplier = null;
			}
		}
		JsonElement supplierObject = gson.toJsonTree(supplier);
		myObj.add("supplierInfo", supplierObject);
		out.println(myObj.toString());

		out.close();

	}

	@RequestMapping(value = "/supplierList", method = RequestMethod.GET)
	public ModelAndView SupplierList(ModelMap model, Principal principal) {
		if (principal == null) {
			return new ModelAndView("redirect:/login");
		}
		List<Supplier> supplierList = commonService.getAllObjectList(SUPPLIER)
				.stream().map(e -> (Supplier) e).collect(Collectors.toList());
		model.put("supplierList", supplierList);
		return new ModelAndView("supplierList", model);
	}
}
