package com.ibasl.cfms.controller;

import java.io.PrintWriter;
import java.security.Principal;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.ibasl.cfms.service.CommonService;
import com.ibasl.cfms.service.UserRoleService;
import com.ibasl.cfms.service.UserService;
import com.ibasl.cfms.util.CFMSEntitys;
import com.ibasl.cfms.util.Constants;
import com.ibasl.cfms.model.Customer;
import com.ibasl.cfms.model.User;
import com.ibasl.cfms.model.UserRole;

@Controller
@PropertySource("classpath:common.properties")
public class UserController implements Constants, CFMSEntitys {
	
	@Autowired
	private CommonService commonService;
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private UserRoleService userRoleService;

	@SuppressWarnings("unused")
	@Autowired
	private JavaMailSender mailSender;

	@Value("${cc.email.addresss}")
	String ccEmailAddresss;

	@Value("${common.email.address}")
	String commonEmailAddress;
	
	@RequestMapping(value = "/newUserForm", method = RequestMethod.GET)
	public ModelAndView addUser(@ModelAttribute("command") User user, BindingResult result, ModelMap model, Principal principal) {
		
		if (principal == null) {
			return new ModelAndView("redirect:/login");
		}
		
		List<Customer>  customerList = commonService.getAllObjectList(CUSTOMER)
				.stream().map(e -> (Customer) e).collect(Collectors.toList());
		
		model.put("customerList", customerList);
		model.put("edit", false);
		return new ModelAndView("addUser", model);
	}
	
	@RequestMapping(value = "/saveUser", method = RequestMethod.POST)
	@ResponseBody
	public ModelAndView saveUser(@ModelAttribute("command") User user, HttpSession session, HttpServletRequest request,
			RedirectAttributes redirectAttributes, Principal principal) {
		
		if (principal == null) {
			return new ModelAndView("redirect:/login");
		}
		
		String name = principal.getName();
		User loginUser =  userService.getUser(name);
		
		Customer customer = null;
		if(user.getCustomerId() != null) {
			customer = (Customer)commonService.getAnObjectByAnyUniqueColumn(CUSTOMER, "id", user.getCustomerId().toString());
		}
				
		if(user.getId() != null) {		
			User userById = (User)commonService.getAnObjectByAnyUniqueColumn(USER, "id", user.getId().toString());
			User userByUserName = (User)commonService.getAnObjectByAnyUniqueColumn(USER, "userName", user.getUserName().toString());
			if(userById.getId().toString().equals(userByUserName.getId().toString())) {
				
				userById.setFullName(user.getFullName());
				
				//password will be eyncrypted
				if(user.getPassword() != null && user.getPassword().length() > 0) {
					userById.setPassword(user.getPassword());
				}
				
				userById.setFullName(user.getFullName());
				userById.setContactNo(user.getContactNo());
				userById.setEmail(user.getEmail());
				if(customer != null) {
					userById.setCustomer(customer);
				}
				
				userById.setStatus(user.getStatus());
				userById.setUpdatedBy(loginUser.getFullName());
				userById.setUpdateDate(new Date());		
				
				commonService.saveOrUpdateModelObjectToDB(userById);
				
				if(user.getAuthority() != null) {
					UserRole userRole = (UserRole) commonService.getAnObjectByAnyUniqueColumn(USER_ROLE, "userId", userById.getId().toString());
					if(!user.getAuthority().equals(userRole.getAuthority())) {
						userRole.setAuthority(user.getAuthority());
						userRoleService.addUserRole(userRole);
					}
				}
				
				
				redirectAttributes.addFlashAttribute("success", "Successfully Saved.");
				return new ModelAndView("redirect:/userList");
			} else {
				redirectAttributes.addFlashAttribute("success", "Operation failed. Please Try again.");
				return new ModelAndView("redirect:/userList");
			}
			
			
		} else {
			User userByUserName = (User)commonService.getAnObjectByAnyUniqueColumn(USER, "userName", user.getUserName().toString());
			if(userByUserName == null) {
				
				//password will be encrypted
				if(user.getPassword() != null && user.getPassword().length() > 0) {
					user.setPassword(user.getPassword());
				} else {
					user.setPassword(DEFAULT_PASSWORD);
				}
				
				if(customer != null) {
					user.setCustomer(customer);
				}
				
				user.setInsertedBy(loginUser.getFullName());
				user.setInsertDate(new Date());
				userService.addUser(user);
				
				//add user role
				User userByUserNameDb = (User)commonService.getAnObjectByAnyUniqueColumn(USER, "userName", user.getUserName().toString());
				UserRole userRole = new UserRole();
				if(user.getAuthority() != null) {
					userRole.setAuthority(user.getAuthority());
				} else {
					userRole.setAuthority(AUTH_USER);
				}
				userRole.setUserId(userByUserNameDb.getId());
				userRoleService.addUserRole(userRole);
				//end
				
				redirectAttributes.addFlashAttribute("success", "Successfully Saved.");
				return new ModelAndView("redirect:/userList");
			} else {
				redirectAttributes.addFlashAttribute("success", "This type of entry already exists. Please try again.");
				return new ModelAndView("redirect:/userList");
			}
			
		}
		
	}
	
	// method to vehicle delete
	@RequestMapping(value = "/deleteUser/{id}", method = RequestMethod.GET)
	public ModelAndView deleteUser(@PathVariable("id") String id, RedirectAttributes redirectAttributes,
			Principal principal, HttpSession session) {
		if (principal == null) {
			return new ModelAndView("redirect:/login");
		}
		
		String name = principal.getName();
		User loginUser =  userService.getUser(name);
		
		User userById = (User)commonService.getAnObjectByAnyUniqueColumn(USER, "id", id);
		userById.setUpdatedBy(loginUser.getFullName());
		userById.setUpdateDate(new Date());
		userById.setStatus(INACTIVE);
		commonService.saveOrUpdateModelObjectToDB(INACTIVE);
		redirectAttributes.addFlashAttribute("success", "Operation Successfull.");
		return new ModelAndView("redirect:/userList");
	}
	
	// method to vehicle show
	@RequestMapping(value = "/showUser/{id}", method = RequestMethod.GET)
	public ModelAndView showUser(@PathVariable("id") String id, ModelMap model, RedirectAttributes redirectAttributes,
			Principal principal) {
		if (principal == null) {
			return new ModelAndView("redirect:/login");
		}
		
		User user = (User) commonService.getAnObjectByAnyUniqueColumn(USER, "id", id);
		UserRole userRole = (UserRole) commonService.getAnObjectByAnyUniqueColumn(USER_ROLE, "userId", user.getId().toString());
		user.setAuthority(userRole.getAuthority());
		model.put("user", user);
		
		return new ModelAndView("showUser", model);
	}

	@RequestMapping(value = "/editUser/{id}", method = RequestMethod.GET)
	public ModelAndView editUser(@ModelAttribute("command") User user, BindingResult result,
			@PathVariable("id") String id, ModelMap model, Principal principal) {
		if (principal == null) {
			return new ModelAndView("redirect:/login");
		}
		
		
		
		User userDb = (User) commonService.getAnObjectByAnyUniqueColumn(USER, "id", id);
		UserRole userRole = (UserRole) commonService.getAnObjectByAnyUniqueColumn(USER_ROLE, "userId", userDb.getId().toString());
		
		List<Customer>  customerList = commonService.getObjectListByAnyColumn(CUSTOMER, "id", userDb.getCustomer().getId().toString())
				.stream().map(e -> (Customer) e).collect(Collectors.toList());
		
		model.put("customerList", customerList);
		
		userDb.setAuthority(userRole.getAuthority());
		model.put("user", userDb);
		
		model.put("edit", true);
		return new ModelAndView("editUser", model);

	}

	@SuppressWarnings("unused")
	@RequestMapping(value = "/checkUniqueUser", method = RequestMethod.POST)
	private @ResponseBody void checkUniqueUser(HttpServletRequest request, Principal principal,
			HttpServletResponse response) throws JsonGenerationException, JsonMappingException, Exception {
		
		String userName = request.getParameter("userName").toString();
		String id = request.getParameter("id");
		
		String toJson = "";
		PrintWriter out = response.getWriter();
		Gson gson = new Gson();
		JsonObject myObj = new JsonObject();
		ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
		User user = (User) commonService.getAnObjectByAnyUniqueColumn(USER, "userName", userName);
		
		User userById = null;
		
		if(id != null && id.length() > 0) {
			userById = (User) commonService.getAnObjectByAnyUniqueColumn(USER, "id", id);
		}
		
		if(user != null && userById != null) {
			if(user.getId().toString().equals(userById.getId().toString())) {
				user = null;
			}
		}
		JsonElement userObject = gson.toJsonTree(user);
		myObj.add("userInfo", userObject);
		out.println(myObj.toString());

		out.close();

	}

	@RequestMapping(value = "/userList", method = RequestMethod.GET)
	public ModelAndView userList(ModelMap model, Principal principal) {
		if (principal == null) {
			return new ModelAndView("redirect:/login");
		}
		List<User> userList = commonService.getAllObjectList(USER)
				.stream().map(e -> (User) e).collect(Collectors.toList());
		
		List<UserRole> userRoleList = commonService.getAllObjectList(USER_ROLE)
				.stream().map(e -> (UserRole) e).collect(Collectors.toList());
		for (User user : userList) {
			for (UserRole userRole : userRoleList) {
				if(user.getId().toString().equals(userRole.getUserId().toString())) {
					user.setAuthority(userRole.getAuthority());
					break;
				}
			}
		}
		model.put("userList", userList);
		return new ModelAndView("userList", model);
	}
}
