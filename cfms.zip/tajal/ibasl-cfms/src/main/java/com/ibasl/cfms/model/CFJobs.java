package com.ibasl.cfms.model;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.ibasl.cfms.model.CommonModel;

@Entity
@Table(name = "cf_jobs")
@AttributeOverrides({ @AttributeOverride(name = "remarks", column = @Column(name = "remarks")),
		@AttributeOverride(name = "createdBy", column = @Column(name = "created_by")),
		@AttributeOverride(name = "createdDate", column = @Column(name = "created_date")),
		@AttributeOverride(name = "modifiedBy", column = @Column(name = "modified_by")),
		@AttributeOverride(name = "modifiedDate", column = @Column(name = "modified_date")),
		@AttributeOverride(name = "status", column = @Column(name = "status")) })
public class CFJobs extends CommonModel {

	private static final long serialVersionUID = -7220600828240370258L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	@ManyToOne
	@JoinColumn(name = "origin_country_id", nullable = true)
	private Country countryOfOrigin;

	@ManyToOne
	@JoinColumn(name = "customer_id", nullable = true)
	private Customer customer;

	@ManyToOne
	@JoinColumn(name = "supplier_id", nullable = true)
	private Supplier supplier;

	@ManyToOne
	@JoinColumn(name = "cf_status_id", nullable = true)
	private CFStatus cfStatus;

	@Column(name = "job_no")
	private String jobNo;

	@Column(name = "bill_no")
	private String billNo;

	@Column(name = "bill_dt")
	private String billDate;

	@Column(name = "lc_no")
	private String lcNo;

	@Column(name = "lc_dt")
	private String lcDate;

	@Column(name = "goods_desc")
	private String goodsDesc;

	@Column(name = "copy_doc_rcv_dt")
	private String copyDocRcvDate;

	@Column(name = "original_doc_rcv_dt")
	private String originalDocRcvDate;

	@Column(name = "eta_bl_dt")
	private String etaBlDate;

	@Column(name = "eta_igm_dt")
	private String etaIgmDate;

	@Column(name = "actual_bathing_dt")
	private String actualBathingDate;

	@Column(name = "cont_unstuffed_dt")
	private String contUnstuffedDate;

	@Column(name = "goods_unstuffed_dt")
	private String goodsUnstuffedDate;

	@Column(name = "exam_dt")
	private String examDate;

	@Column(name = "exam_rpt_rcv_dt")
	private String examRptRcvDate;

	@Column(name = "bsti_test_dt")
	private String bstiTestDate;

	@Column(name = "chemical_test_dt")
	private String chemicalTestDate;

	@Column(name = "radiation_dt")
	private String radiationDate;

	@Column(name = "qurantime_dt")
	private String qurantimeDate;

	@Column(name = "report_rcv_dt")
	private String reportRcvDate;

	@Column(name = "asses_complete_dt")
	private String assesCompleteDate;

	@Column(name = "cost_through_dt")
	private String costThroughDate;

	@Column(name = "cost_rcv_dt")
	private String costRcvDate;

	@Column(name = "cost_paid_dt")
	private String costPaidDate;

	@Column(name = "custom_duty_bdt")
	private Double customDutyBDT;

	@Column(name = "asses_value_bdt")
	private Double assesValueBDT;

	@Column(name = "port_bill_amount_bdt")
	private Double portBillAmountBDT;

	@Column(name = "shipping_bill_amount_bdt")
	private Double shippingBillAmountBDT;

	@Column(name = "delivery_dt")
	private String deliveryDate;

	@Transient
	private Integer countryOfOriginId;

	@Transient
	private Integer customerId;

	@Transient
	private Integer supplierId;

	@Transient
	private Integer cfStatusId;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Country getCountryOfOrigin() {
		return countryOfOrigin;
	}

	public void setCountryOfOrigin(Country countryOfOrigin) {
		this.countryOfOrigin = countryOfOrigin;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Supplier getSupplier() {
		return supplier;
	}

	public void setSupplier(Supplier supplier) {
		this.supplier = supplier;
	}

	public CFStatus getCfStatus() {
		return cfStatus;
	}

	public void setCfStatus(CFStatus cfStatus) {
		this.cfStatus = cfStatus;
	}

	public String getJobNo() {
		return jobNo;
	}

	public void setJobNo(String jobNo) {
		this.jobNo = jobNo;
	}

	public String getBillNo() {
		return billNo;
	}

	public void setBillNo(String billNo) {
		this.billNo = billNo;
	}

	public String getBillDate() {
		return billDate;
	}

	public void setBillDate(String billDate) {
		this.billDate = billDate;
	}

	public String getLcNo() {
		return lcNo;
	}

	public void setLcNo(String lcNo) {
		this.lcNo = lcNo;
	}

	public String getLcDate() {
		return lcDate;
	}

	public void setLcDate(String lcDate) {
		this.lcDate = lcDate;
	}

	public String getGoodsDesc() {
		return goodsDesc;
	}

	public void setGoodsDesc(String goodsDesc) {
		this.goodsDesc = goodsDesc;
	}

	public String getCopyDocRcvDate() {
		return copyDocRcvDate;
	}

	public void setCopyDocRcvDate(String copyDocRcvDate) {
		this.copyDocRcvDate = copyDocRcvDate;
	}

	public String getOriginalDocRcvDate() {
		return originalDocRcvDate;
	}

	public void setOriginalDocRcvDate(String originalDocRcvDate) {
		this.originalDocRcvDate = originalDocRcvDate;
	}

	public String getEtaBlDate() {
		return etaBlDate;
	}

	public void setEtaBlDate(String etaBlDate) {
		this.etaBlDate = etaBlDate;
	}

	public String getEtaIgmDate() {
		return etaIgmDate;
	}

	public void setEtaIgmDate(String etaIgmDate) {
		this.etaIgmDate = etaIgmDate;
	}

	public String getActualBathingDate() {
		return actualBathingDate;
	}

	public void setActualBathingDate(String actualBathingDate) {
		this.actualBathingDate = actualBathingDate;
	}

	public String getContUnstuffedDate() {
		return contUnstuffedDate;
	}

	public void setContUnstuffedDate(String contUnstuffedDate) {
		this.contUnstuffedDate = contUnstuffedDate;
	}

	public String getGoodsUnstuffedDate() {
		return goodsUnstuffedDate;
	}

	public void setGoodsUnstuffedDate(String goodsUnstuffedDate) {
		this.goodsUnstuffedDate = goodsUnstuffedDate;
	}

	public String getExamDate() {
		return examDate;
	}

	public void setExamDate(String examDate) {
		this.examDate = examDate;
	}

	public String getExamRptRcvDate() {
		return examRptRcvDate;
	}

	public void setExamRptRcvDate(String examRptRcvDate) {
		this.examRptRcvDate = examRptRcvDate;
	}

	public String getBstiTestDate() {
		return bstiTestDate;
	}

	public void setBstiTestDate(String bstiTestDate) {
		this.bstiTestDate = bstiTestDate;
	}

	public String getChemicalTestDate() {
		return chemicalTestDate;
	}

	public void setChemicalTestDate(String chemicalTestDate) {
		this.chemicalTestDate = chemicalTestDate;
	}

	public String getRadiationDate() {
		return radiationDate;
	}

	public void setRadiationDate(String radiationDate) {
		this.radiationDate = radiationDate;
	}

	public String getQurantimeDate() {
		return qurantimeDate;
	}

	public void setQurantimeDate(String qurantimeDate) {
		this.qurantimeDate = qurantimeDate;
	}

	public String getReportRcvDate() {
		return reportRcvDate;
	}

	public void setReportRcvDate(String reportRcvDate) {
		this.reportRcvDate = reportRcvDate;
	}

	public String getAssesCompleteDate() {
		return assesCompleteDate;
	}

	public void setAssesCompleteDate(String assesCompleteDate) {
		this.assesCompleteDate = assesCompleteDate;
	}

	public String getCostThroughDate() {
		return costThroughDate;
	}

	public void setCostThroughDate(String costThroughDate) {
		this.costThroughDate = costThroughDate;
	}

	public String getCostRcvDate() {
		return costRcvDate;
	}

	public void setCostRcvDate(String costRcvDate) {
		this.costRcvDate = costRcvDate;
	}

	public String getCostPaidDate() {
		return costPaidDate;
	}

	public void setCostPaidDate(String costPaidDate) {
		this.costPaidDate = costPaidDate;
	}

	public Double getCustomDutyBDT() {
		return customDutyBDT;
	}

	public void setCustomDutyBDT(Double customDutyBDT) {
		this.customDutyBDT = customDutyBDT;
	}

	public Double getAssesValueBDT() {
		return assesValueBDT;
	}

	public void setAssesValueBDT(Double assesValueBDT) {
		this.assesValueBDT = assesValueBDT;
	}

	public Double getPortBillAmountBDT() {
		return portBillAmountBDT;
	}

	public void setPortBillAmountBDT(Double portBillAmountBDT) {
		this.portBillAmountBDT = portBillAmountBDT;
	}

	public Double getShippingBillAmountBDT() {
		return shippingBillAmountBDT;
	}

	public void setShippingBillAmountBDT(Double shippingBillAmountBDT) {
		this.shippingBillAmountBDT = shippingBillAmountBDT;
	}

	public String getDeliveryDate() {
		return deliveryDate;
	}

	public void setDeliveryDate(String deliveryDate) {
		this.deliveryDate = deliveryDate;
	}

	public Integer getCountryOfOriginId() {
		return countryOfOriginId;
	}

	public void setCountryOfOriginId(Integer countryOfOriginId) {
		this.countryOfOriginId = countryOfOriginId;
	}

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public Integer getSupplierId() {
		return supplierId;
	}

	public void setSupplierId(Integer supplierId) {
		this.supplierId = supplierId;
	}

	public Integer getCfStatusId() {
		return cfStatusId;
	}

	public void setCfStatusId(Integer cfStatusId) {
		this.cfStatusId = cfStatusId;
	}

	public CFJobs() {
		super();
	}

}
