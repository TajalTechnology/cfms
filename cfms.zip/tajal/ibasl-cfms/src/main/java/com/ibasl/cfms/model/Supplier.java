package com.ibasl.cfms.model;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "supplier")
@AttributeOverrides({ @AttributeOverride(name = "remarks", column = @Column(name = "remarks")),
		@AttributeOverride(name = "createdBy", column = @Column(name = "created_by")),
		@AttributeOverride(name = "createdDate", column = @Column(name = "created_date")),
		@AttributeOverride(name = "modifiedBy", column = @Column(name = "modified_by")),
		@AttributeOverride(name = "modifiedDate", column = @Column(name = "modified_date")),
		@AttributeOverride(name = "status", column = @Column(name = "status")) })
public class Supplier extends CommonModel {

	private static final long serialVersionUID = -723583058586873479L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	@Column(name = "name")
	private String name;

	@Column(name = "sup_address")
	private String supplierAddress;

	@Column(name = "contact_no")
	private String contactNo;

	@Column(name = "contact_person")
	private String contactPerson;

	@Column(name = "supplier_id")
	private String supplierId;

	@ManyToOne
	@JoinColumn(name = "country_id", nullable = true)
	private Country country;

	@Transient
	private String countryId;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSupplierAddress() {
		return supplierAddress;
	}

	public void setSupplierAddress(String supplierAddress) {
		this.supplierAddress = supplierAddress;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public String getContactPerson() {
		return contactPerson;
	}

	public void setContactPerson(String contactPerson) {
		this.contactPerson = contactPerson;
	}

	public Country getCountry() {
		return country;
	}

	public void setCountry(Country country) {
		this.country = country;
	}

	public String getCountryId() {
		return countryId;
	}

	public void setCountryId(String countryId) {
		this.countryId = countryId;
	}

	public String getSupplierId() {
		return supplierId;
	}

	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}

	public Supplier() {
		super();
	}
}
