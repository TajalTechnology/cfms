package com.ibasl.cfms.util;

public interface CFMSEntitys {
	public static final String USER = "User"; 
	public static final String USER_ROLE = "UserRole"; 
	public static final String CUSTOMER = "Customer"; 
	public static final String SUPPLIER = "Supplier"; 
	public static final String COUNTRY = "Country"; 
	public static final String CF_STATUS = "CFStatus"; 
	public static final String CF_JOBS = "CFJobs"; 
}
